const express = require('express');
const fs = require('fs');
const path = require('path');




class myBanana {
    constructor() {
        this.app = express();
        this.filePath = './bananas.json';
        this.app.use(express.json());
        this.setUpRoutes();
        
    }
    

    readBananas = () => {
      const data = fs.readFileSync(this.filePath, `utf-8`);
      return JSON.parse(data);
    };

    writeBanana = (data) => {
        fs.writeFileSync(this.filePath, JSON.stringify(data, null, 2));
    };



    getAllBananas(req, res){
     const data = this.readBananas();
     res.json(data);
    
    }
    setUpRoutes() {

       
        this.app.get("/", (req,res) => this.getAllBananas(req,res))
        this.app.post("/add", (req,res) => this.makeBanana(req,res))
        this.app.get("/home", (req, res) => {
            res.sendFile(path.join(__dirname, 'home.html'));
        })
      }

      makeBanana(req, res) {
            const banana = this.readBananas();
            const newBanana = {
                //shorter if statement
              id: banana.length ? banana[banana.length - 1].id + 1 : 1,
              type: req.body.type,
              price: req.body.price
                       
            };
         
            if (!newBanana.type || !newBanana.price) {
              return res.status(400).json({ message: 'All fields are required' });
            }
            banana.push(newBanana);
            this.writeBanana(banana);  // Write the updated list of people to the storage/file
            res.status(201).json(newBanana);  // Return the newly created person
          }



start(port = 3000){
    this.app.listen(port, () => {
        console.log(`Example app listening at http://localhost:${port}`)
    });

}


}

const app = new myBanana();
app.start();

